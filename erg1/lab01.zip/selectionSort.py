import numpy as np
from numpy.random import randint

# Sort the array A[1..n] using the selection sort algorithm
# Loop invariant: at the start of each iteration A[1..j-1]
# consists of the j-1 smallest elements of A[1..n] in sorted order

def selectionSortInc(A, n):
    for j in range(1, n):
        smallest = j
        for i in range(j+1, n+1):
            if A[i] < A[smallest]: smallest = i
        A[j], A[smallest] = A[smallest], A[j]

# Sort the array A[1..n] in decrasing order using the insertion sort algorithm

def selectionSortDec(A, n):
    for j in range(1, n):
        largest = j
        for i in range(j+1, n+1):
            if A[i] > A[largest]: largest = i
        A[j], A[largest] = A[largest], A[j]

# Sort the array A[1..n] in increasing or decrasing order using the insertion sort algorithm

def selectionSort(A, n, reverse=False):
    if reverse:
        selectionSortDec(A, n)
    else:
        selectionSortInc(A, n)

# Build a random integer array

n = 10
A = randint(1, high=100, size=n+1)
print(A[1:])

# Sort with selection sort

selectionSort(A, n)
print(A[1:])
