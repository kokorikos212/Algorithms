import numpy as np
from numpy.random import randint

# Sort the array A[1..n] using the insertion sort algorithm

def insertionSortInc(A, n):
    for j in range(2, n+1):
        key = A[j]
        i = j - 1
        while i > 0 and A[i] > key:
            A[i+1] = A[i]
            i = i - 1
        A[i+1] = key

# Sort the array A[1..n] in decrasing order using the insertion sort algorithm

def insertionSortDec(A, n):
    for j in range(2, n+1):
        key = A[j]
        i = j - 1
        while i > 0 and A[i] < key:
            A[i+1] = A[i]
            i = i - 1
        A[i+1] = key

# Sort the array A[1..n] in increasing or decrasing order using the insertion sort algorithm

def insertionSort(A, n, reverse=False):
    if reverse:
        insertionSortDec(A, n)
    else:
        insertionSortInc(A, n)

# Build a random integer array

n = 20
A = randint(1, high=100, size=n+1)
print(A[1:])

# Sort with insertion sort

insertionSort(A, n)
print(A[1:])
