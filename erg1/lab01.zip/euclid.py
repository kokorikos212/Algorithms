
def Euclid(m, n):
    while True:
        r = m % n
        if r == 0: break
        m = n
        n = r
    return n

def recEuclid(m, n):
    r = m % n
    if r == 0: return n
    return recEuclid(n, r)

m = 1769
n = 551

print(Euclid(m,n))
print(recEuclid(m,n))
